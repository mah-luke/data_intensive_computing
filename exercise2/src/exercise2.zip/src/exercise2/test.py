from pathlib import Path


print((Path().resolve().parent.parent))


print(Path().hardlink_to














